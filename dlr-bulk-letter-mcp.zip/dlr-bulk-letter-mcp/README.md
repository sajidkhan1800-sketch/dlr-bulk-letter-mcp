# DLR Bulk Letter MCP Server

FDA Division of Labeling Review — Bulk Decision Letter Sender
Deployed on Railway as an SSE/HTTP MCP server.

---

## Railway Environment Variables

Set these in your Railway project dashboard under **Variables**:

| Variable        | Description                        | Example                        |
|-----------------|------------------------------------|--------------------------------|
| `SENDER_NAME`   | Display name in Gmail inbox        | `Sajid Khan`                   |
| `SENDER_EMAIL`  | Gmail address to send from         | `sajidkhan1800@gmail.com`      |
| `CC_EMAIL`      | Address to CC on every letter      | `sajidkhan1800@gmail.com`      |
| `GMAIL_APP_PASS`| Gmail App Password (16 chars)      | `xxxx xxxx xxxx xxxx`          |

> Railway automatically injects the `PORT` variable — do not set it manually.

---

## MCP Tools

| Tool                    | Description                                      |
|-------------------------|--------------------------------------------------|
| `dlr_status`            | Check server, template, and CSV state            |
| `dlr_load_csv`          | Load applicant CSV (default or paste CSV text)   |
| `dlr_preview_applicants`| List all loaded applicants                       |
| `dlr_send_letters`      | Send letters (optional: filter_decision, filter_anda) |

---

## Team Setup (claude_desktop_config.json)

After Railway deploys, share this config with your team.
Replace `YOUR-APP` with your actual Railway app name:

```json
{
  "mcpServers": {
    "bulk-letter-mcp": {
      "type": "url",
      "url": "https://YOUR-APP.up.railway.app/sse"
    }
  }
}
```

File location:
- **Windows**: `%APPDATA%\Claude\claude_desktop_config.json`
- **Mac**: `~/Library/Application Support/Claude/claude_desktop_config.json`

---

## CSV Format

Required columns:

```
ANDA No, Drug Name, Therapeutic Class, DLR POC, FDA Labeling Decision,
Applicant Name, Applicant POC, Applicant Address, Applicant Email
```

Valid `FDA Labeling Decision` values:
- `Acceptable`
- `Acceptable-Minor Deficiencies`
- `Acceptable-Major Deficiencies`
- `Not Acceptable`
