"""
BulkLetterToApplicant MCP Server — Railway / SSE Edition
Sends personalised FDA DLR labeling decision letters to applicants via Gmail.
Transport: SSE (HTTP) for multi-user cloud deployment on Railway.
"""

import io
import csv
import json
import smtplib
import os
from datetime import datetime
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path
from typing import List, Optional

from docx import Document as DocxDocument
from mcp.server.fastmcp import FastMCP
from pydantic import BaseModel, Field, ConfigDict

# ── constants ─────────────────────────────────────────────────────────────────
BASE_DIR        = Path(__file__).parent
DEFAULT_CSV     = BASE_DIR / "anda_labeling_data.csv"
TEMPLATE_PATH   = BASE_DIR / "DLR_Labeling_Decision_Letter_Template.docx"

# Read from Railway environment variables (set in Railway dashboard)
SENDER_NAME     = os.environ.get("SENDER_NAME",   "Sajid Khan")
SENDER_EMAIL    = os.environ.get("SENDER_EMAIL",  "sajidkhan1800@gmail.com")
CC_EMAIL        = os.environ.get("CC_EMAIL",       "sajidkhan1800@gmail.com")
GMAIL_APP_PASS  = os.environ.get("GMAIL_APP_PASS", "xnuy lbxn ctnf qrbx")

SMTP_HOST = "smtp.gmail.com"
SMTP_PORT = 587

# Port for Railway (Railway injects PORT env var)
PORT = int(os.environ.get("PORT", 8000))

# Runtime state
_loaded_rows: List[dict] = []

# ── MCP server (SSE transport for cloud) ─────────────────────────────────────
mcp = FastMCP(
    "bulk_letter_mcp",
    host="0.0.0.0",
    port=PORT,
)


# ── helpers ───────────────────────────────────────────────────────────────────

def _parse_csv_text(text: str) -> List[dict]:
    reader = csv.DictReader(io.StringIO(text.strip()))
    return [{k.strip(): v.strip() for k, v in row.items()} for row in reader]


def _load_default_csv() -> List[dict]:
    with open(DEFAULT_CSV, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        return [{k.strip(): v.strip() for k, v in row.items()} for row in reader]


def _fill_template(row: dict) -> bytes:
    replacements = {
        "[MM/DD/YYYY]":            datetime.today().strftime("%m/%d/%Y"),
        "[ANDA No.]":              row.get("ANDA No", ""),
        "[Drug Name]":             row.get("Drug Name", ""),
        "[Applicant Name]":        row.get("Applicant Name", ""),
        "[Applicant POC]":         row.get("Applicant POC", ""),
        "[Applicant Address]":     row.get("Applicant Address", ""),
        "[Applicant Email]":       row.get("Applicant Email", ""),
        "[DLR POC]":               row.get("DLR POC", ""),
        "[FDA Labeling Decision]": row.get("FDA Labeling Decision", ""),
        "[DLR POC Email]":         "dlr-reviewer@fda.hhs.gov",
    }
    doc = DocxDocument(TEMPLATE_PATH)
    for para in doc.paragraphs:
        for run in para.runs:
            for token, value in replacements.items():
                if token in run.text:
                    run.text = run.text.replace(token, value)
    for table in doc.tables:
        for trow in table.rows:
            for cell in trow.cells:
                for para in cell.paragraphs:
                    for run in para.runs:
                        for token, value in replacements.items():
                            if token in run.text:
                                run.text = run.text.replace(token, value)
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


def _send_one_email(row: dict) -> dict:
    applicant = row.get("Applicant Name", "Applicant")
    drug      = row.get("Drug Name", "")
    anda      = row.get("ANDA No", "")
    decision  = row.get("FDA Labeling Decision", "")
    to_email  = row.get("Applicant Email", "")

    try:
        docx_bytes = _fill_template(row)
        safe_drug  = "".join(c if c.isalnum() or c in " _-" else "_" for c in drug)
        filename   = f"DLR_Decision_{anda}_{safe_drug}.docx"

        msg = MIMEMultipart()
        msg["From"]    = f"{SENDER_NAME} <{SENDER_EMAIL}>"
        msg["To"]      = to_email
        msg["CC"]      = CC_EMAIL
        msg["Subject"] = f"FDA DLR Labeling Review Decision — {drug} ({anda})"

        body = (
            f"Dear {applicant},\n\n"
            f"Please find attached the FDA Division of Labeling Review (DLR) decision letter "
            f"for {drug} (ANDA {anda}).\n\n"
            f"Labeling Decision: {decision}\n\n"
            f"Please refer to the attached letter for full details and any required next steps.\n\n"
            f"This message was sent on behalf of the FDA Center for Drug Evaluation and Research, "
            f"Office of Generic Drugs, Division of Labeling Review.\n"
        )
        msg.attach(MIMEText(body, "plain"))

        part = MIMEBase(
            "application",
            "vnd.openxmlformats-officedocument.wordprocessingml.document"
        )
        part.set_payload(docx_bytes)
        encoders.encode_base64(part)
        part.add_header("Content-Disposition", f'attachment; filename="{filename}"')
        msg.attach(part)

        recipients = list({to_email, CC_EMAIL})
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.starttls()
            server.login(SENDER_EMAIL, GMAIL_APP_PASS)
            server.sendmail(SENDER_EMAIL, recipients, msg.as_string())

        return {"anda": anda, "applicant": applicant, "drug": drug,
                "decision": decision, "to": to_email, "cc": CC_EMAIL,
                "status": "sent", "error": None}

    except Exception as e:
        return {"anda": anda, "applicant": applicant, "drug": drug,
                "decision": decision, "to": to_email, "cc": CC_EMAIL,
                "status": "failed", "error": str(e)}


# ── MCP tools ─────────────────────────────────────────────────────────────────

class LoadCsvInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    csv_text: Optional[str] = Field(
        default=None,
        description=(
            "Raw CSV text to load. If omitted, the bundled anda_labeling_data.csv is used. "
            "Must include headers: ANDA No, Drug Name, Applicant Name, Applicant POC, "
            "Applicant Email, Applicant Address, DLR POC, FDA Labeling Decision."
        )
    )


@mcp.tool(name="dlr_load_csv")
async def dlr_load_csv(params: LoadCsvInput) -> str:
    """Load applicant data from a CSV into the server's working memory."""
    global _loaded_rows
    try:
        if params.csv_text:
            _loaded_rows = _parse_csv_text(params.csv_text)
            source = "provided CSV text"
        else:
            _loaded_rows = _load_default_csv()
            source = "bundled anda_labeling_data.csv"

        required = {"ANDA No", "Drug Name", "Applicant Name", "Applicant POC",
                    "Applicant Email", "Applicant Address", "DLR POC", "FDA Labeling Decision"}
        if _loaded_rows:
            missing = required - set(_loaded_rows[0].keys())
            if missing:
                _loaded_rows = []
                return json.dumps({"success": False,
                    "error": f"Missing required columns: {', '.join(sorted(missing))}"}, indent=2)

        return json.dumps({
            "success": True, "source": source,
            "rows_loaded": len(_loaded_rows),
            "columns": list(_loaded_rows[0].keys()) if _loaded_rows else [],
            "message": f"Successfully loaded {len(_loaded_rows)} applicant rows from {source}."
        }, indent=2)

    except Exception as e:
        return json.dumps({"success": False, "error": str(e)}, indent=2)


@mcp.tool(name="dlr_preview_applicants")
async def dlr_preview_applicants() -> str:
    """List all applicants currently loaded in memory."""
    if not _loaded_rows:
        return json.dumps({"success": False,
            "error": "No CSV loaded. Call dlr_load_csv first."}, indent=2)

    preview = [{
        "ANDA No":               row.get("ANDA No", ""),
        "Drug Name":             row.get("Drug Name", ""),
        "Applicant Name":        row.get("Applicant Name", ""),
        "Applicant POC":         row.get("Applicant POC", ""),
        "FDA Labeling Decision": row.get("FDA Labeling Decision", ""),
        "Applicant Email":       row.get("Applicant Email", ""),
        "DLR POC":               row.get("DLR POC", ""),
    } for row in _loaded_rows]

    return json.dumps({"success": True, "total": len(preview), "applicants": preview}, indent=2)


class SendLettersInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    filter_decision: Optional[str] = Field(default=None)
    filter_anda: Optional[str] = Field(default=None)


@mcp.tool(name="dlr_send_letters")
async def dlr_send_letters(params: SendLettersInput) -> str:
    """Send personalised FDA DLR labeling decision letters to all (or filtered) loaded applicants."""
    if not _loaded_rows:
        return json.dumps({"success": False,
            "error": "No CSV loaded. Call dlr_load_csv first."}, indent=2)

    rows = _loaded_rows[:]

    if params.filter_anda:
        rows = [r for r in rows if r.get("ANDA No", "").strip() == params.filter_anda.strip()]
        if not rows:
            return json.dumps({"success": False,
                "error": f"No applicant found with ANDA No '{params.filter_anda}'."}, indent=2)

    if params.filter_decision:
        rows = [r for r in rows if r.get("FDA Labeling Decision", "").strip() == params.filter_decision.strip()]
        if not rows:
            return json.dumps({"success": False,
                "error": f"No applicants found with decision '{params.filter_decision}'."}, indent=2)

    results = [_send_one_email(row) for row in rows]
    sent    = sum(1 for r in results if r["status"] == "sent")
    failed  = sum(1 for r in results if r["status"] == "failed")

    return json.dumps({
        "success": True, "total": len(results), "sent": sent, "failed": failed,
        "from": f"{SENDER_NAME} <{SENDER_EMAIL}>", "cc": CC_EMAIL, "results": results
    }, indent=2)


@mcp.tool(name="dlr_status")
async def dlr_status() -> str:
    """Check the current state of the BulkLetterToApplicant MCP server."""
    return json.dumps({
        "server":            "bulk_letter_mcp (Railway SSE)",
        "transport":         "SSE / HTTP",
        "port":              PORT,
        "template_ready":    TEMPLATE_PATH.exists(),
        "template_file":     TEMPLATE_PATH.name,
        "default_csv_ready": DEFAULT_CSV.exists(),
        "default_csv_file":  DEFAULT_CSV.name,
        "rows_loaded":       len(_loaded_rows),
        "sender":            f"{SENDER_NAME} <{SENDER_EMAIL}>",
        "cc_email":          CC_EMAIL,
        "smtp_host":         SMTP_HOST,
        "available_tools": [
            "dlr_status             — check server state",
            "dlr_load_csv           — load applicant CSV",
            "dlr_preview_applicants — list all loaded applicants",
            "dlr_send_letters       — send letters (optional filters)",
        ]
    }, indent=2)


# ── entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    mcp.run(transport="sse")
